"""
Safe browser actions.
"""

import re
import webbrowser
from urllib.parse import quote_plus
from app.utils.logger import get_logger

logger = get_logger()

_WELL_KNOWN_SITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "github": "https://www.github.com",
    "gmail": "https://mail.google.com",
    "wikipedia": "https://www.wikipedia.org",
    "amazon": "https://www.amazon.in",
    "linkedin": "https://www.linkedin.com",
    "stackoverflow": "https://stackoverflow.com",
}
_SIMPLE_DOMAIN_RE = re.compile(r"^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(/.*)?$")


def open_website(site):
    key = site.strip().lower()
    if key in _WELL_KNOWN_SITES:
        url = _WELL_KNOWN_SITES[key]
    elif re.match(r"^https?://", key):
        url = key
    elif _SIMPLE_DOMAIN_RE.match(key):
        url = "https://" + key
    else:
        return False, f"I don't recognize '{site}' as a safe website."
    try:
        webbrowser.open(url)
        return True, f"Opening {site}."
    except Exception as exc:
        logger.error("open_website failed: %s", exc)
        return False, f"I couldn't open {site}."


def web_search(query):
    if not query.strip():
        return False, "What would you like me to search for?"
    try:
        webbrowser.open("https://www.google.com/search?q=" + quote_plus(query.strip()))
        return True, f"Searching Google for {query}."
    except Exception as exc:
        logger.error("web_search failed: %s", exc)
        return False, "I couldn't open the search."


def youtube_search(query):
    if not query.strip():
        return False, "What would you like me to search for on YouTube?"
    try:
        webbrowser.open("https://www.youtube.com/results?search_query=" + quote_plus(query.strip()))
        return True, f"Searching YouTube for {query}."
    except Exception as exc:
        logger.error("youtube_search failed: %s", exc)
        return False, "I couldn't open YouTube search."
